<#

    https://www.terraform.io/docs/providers/azurerm/index.html
    We recommend using either a Service Principal or Managed Service Identity when running Terraform non-interactively (such as when running Terraform in a CI server) - and authenticating using the Azure CLI when running Terraform locally.

    Add to Path or use Cloud Shell
    https://docs.microsoft.com/en-us/azure/virtual-machines/linux/terraform-install-configure
    https://www.terraform.io/downloads.html

    Terraform only supports authenticating using the az CLI (and this must be available on your PATH)

    Authenticating via the Azure CLI is only supported when using a User Account. If you're using a Service Principal (for example via az login --service-principal) you should instead authenticate via the Service Principal directly (either using a Client Secret or a Client Certificate).

    https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?view=azure-cli-latest

#>

Start-Process 'https://www.terraform.io/downloads.html'

Start-Process 'https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?view=azure-cli-latest'

Get-Command terraform

terraform --version

az --version

# Authenticate
az login

az account list
az account show

# Configure the context of the subscription you want to operate against:
az account set -s "b7f543e7-1234-5678-8b16-e8e94170be88"

# Alternatively, use Cloud Shell which has both CLI tools available - authenticated using the logged on user
Start-Process 'https://shell.azure.com'

# Bonus tip: Cloud Shell is also available in VS Code via the Azure extension (F1->type "Cloud Shell")

Get-Command terraform

# Navigate to the folder you want to deploy, for example:
cd "~\Git\Crayon Demo - Terraform\intro\Demo 1 - Resource Group"

psedit .\main.tf

dir

terraform init

dir

terraform plan

terraform apply

# When Terraform plans to make changes, it prints a human-readable summary to the terminal. It can also, when run with -out=<PATH>, write a much more detailed binary plan file, which can later be used to apply those changes.
terraform plan -out=tfplan

terraform apply "tfplan"

terraform show

terraform destroy

# Tip: PowerShell module which parses the stdout from terraform plan and returns json
Install-Module -Name PSTerraformParser

terraform plan -no-color >> .\MyPlan.txt

Read-TerraformPlan -Path .\MyPlan.txt

# Parameters
cd "~\Git\Crayon Demo - Terraform\intro\Demo 2 - Parameters"
psedit .\main.tf

terraform init

terraform plan -out=tfplan

terraform apply "tfplan"


# State and variables
cd "~\Git\Crayon Demo - Terraform\intro\Demo 3 - State"
psedit .\main.tf

terraform init

terraform plan -out=tfplan

terraform apply "tfplan"


# Modules
cd "~\Git\Crayon Demo - Terraform\intro\Demo 4 - Modules"
psedit .\main.tf

terraform init

terraform plan -out=tfplan

terraform apply "tfplan"

psedit "~\Git\Crayon Demo - Terraform\structure_2\scripts\deploy-azurepreproductioninstance.ps1"
