# Terraform import

Terraform is able to import existing infrastructure. This allows you take resources you've created by some other means and bring it under Terraform management.

This is a great way to slowly transition infrastructure to Terraform, or to be able to be confident that you can use Terraform in the future if it potentially doesn't support every feature you need today.

https://www.terraform.io/docs/import/

## Examples of using Terraform import

### infrastructure-rg in Crayon Demo

terraform import module.azurerm-key-vault.azurerm-key-vault.vault /subscriptions/27cd3b4b-c113-43f0-a30a-0689ab784311/resourceGroups/infrastructure-rg/providers/Microsoft.KeyVault/vaults/test-vault

