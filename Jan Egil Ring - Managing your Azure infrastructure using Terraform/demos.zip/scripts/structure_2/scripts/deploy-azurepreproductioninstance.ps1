<#

This script can be used for manual deployment, and is not needed if a release pipeline in Azure DevOps is leveraged.

Prerequisites:
 - Azure CLI - https://docs.microsoft.com/en-us/cli/azure/install-azure-cli
 - Terraform CLI - https://www.terraform.io/downloads.html
 - Contributor permissions on the Crayon Demo subscription

The below code is being run from PowerShell Core
https://github.com/PowerShell/PowerShell

#>

cd "~\Git\Crayon Demo - Terraform\structure_2\terraform\configurations\crayon-demo-unicorn\"

$VariablePath = '-var-file=' + (Resolve-Path "~\Git\Crayon Demo - Terraform\structure_2\terraform\environments\preproduction\crayon-unicorn-preproduction.tfvars").Path

az login

az account set -s "b7f543e7-1234-5678-8b16-e8e94170be88"

terraform init  -backend-config "storage_account_name=crayondemoterraformstate" -backend-config "container_name=tfstate" -backend-config "key=crayon-demo_unicorn-preproduction-rg.terraform.tfstate"

terraform plan $VariablePath

terraform apply $VariablePath --auto-approve

& "~\Git\Crayon Demo - Terraform\structure_2\scripts\scripts\invoke-azurepreproductioninstancepostdeployment.ps1"

# Teardown
terraform destroy $VariablePath --auto-approve