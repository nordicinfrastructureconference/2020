﻿<#

Script for adding nodes to internal DNS zones after a new deployment.
This script can be used for manual deployment, and is not needed if a release pipeline in Azure DevOps is leveraged.

Prerequisites:
 - Azure PowerShell modules - https://docs.microsoft.com/en-us/powershell/azure
 - Read permissions on the Crayon Demo subscription
 - Administrator access to Crayon Demo`s internal DNS servers

#>

$ResourceGroupName = 'unicorn-preprod-rg'
$SubscriptionId = 'b7f543e7-1234-5678-8b16-e8e94170be88'
$InternalDnsServer = 'DEMODC01'
$InternalDnsZoneName = 'demo.crayon.com'
$ExternalAgwDnsName = 'unicorn-preprod'


Connect-AzAccount

Set-AzContext $SubscriptionId

$NICs = Get-AzNetworkInterface -ResourceGroupName $ResourceGroupName

$NICs | ForEach-Object {

    Write-Output "Processing $($PSItem.Name)"

    if ($PSItem.IpConfigurations[0].PrivateIpAllocationMethod -ne 'Static') {

        Write-Output "Setting $($PSItem.IpConfigurations[0].PrivateIpAddress) for static IP allocation"

        $PSItem.IpConfigurations[0].PrivateIpAllocationMethod = 'Static'

        $null = Set-AzNetworkInterface -NetworkInterface $PSItem

    }

}


$Nodes = Get-AzNetworkInterface -ResourceGroupName $ResourceGroupName | Where-Object { $PSItem.VirtualMachine -NE $null } | foreach {

    $VM = Get-AzVM | Where-Object id -eq $PSItem.VirtualMachine.Id

    [pscustomobject]@{
        VMName    = $VM.Name
        IPAddress = $PSItem.IpConfigurations.PrivateIpAddress
    }

}

$Nodes | ForEach-Object {

    Add-DnsServerResourceRecord -ZoneName $InternalDnsZoneName -CimSession $InternalDnsServer -Name $PSItem.VMName -IPv4Address $PSItem.IPAddress -A
    Add-DnsServerResourceRecord -ZoneName reddog.microsoft.com -CimSession $InternalDnsServer -Name $PSItem.VMName -IPv4Address $PSItem.IPAddress -A

}

$Nodes | where VMName -like "*preprodapp*" | foreach {

    Add-DnsServerResourceRecord -ZoneName $InternalDnsZoneName -CimSession $InternalDnsServer -Name unicorn-int -IPv4Address $PSItem.IPAddress -A

}


$ExternalAgw = Get-AzApplicationGateway -ResourceGroupName $ResourceGroupName -Name unicorn-preproduction-external-agw
$ExternalAgw.FrontendIPConfigurations[0].PublicIPAddress

$PublicIpAddress = Get-AzPublicIpAddress -ResourceGroupName $ResourceGroupName | Where-Object Id -eq $ExternalAgw.FrontendIPConfigurations[0].PublicIPAddress.Id

$PublicIpAddress.IpAddress

Add-DnsServerResourceRecord -ZoneName $InternalDnsZoneName -CimSession $InternalDnsServer -Name $ExternalAgwDnsName -IPv4Address $PublicIpAddress.IpAddress -A
