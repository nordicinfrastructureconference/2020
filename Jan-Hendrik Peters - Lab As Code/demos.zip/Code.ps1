﻿break
'Good afternoon, ladies and gentlemen' | Get-Translation -From en-us -To nb # Install-Module PSTranslate ;)
Get-Introduction

#region Getting started
# Getting started is easy
# Installer available (msi, offline) on GitHub
Install-Module AutomatedLab -AllowClobber
Import-Module AutomatedLab

# First things first - only done once
New-LabSourcesFolder -Drive D -Force
Enable-LabHostRemoting -Force
Enable-LabTelemetry # Or Disable-LabTelemetry, that's up to you! It is DISABLED by default.

# Provide the ISOs you want, whether it is an operating system or a product like SQL, Exchange, Azure DevOps Server, ...
$serverUri = 'https://software-download.microsoft.com/download/pr/17763.737.190906-2324.rs5_release_svc_refresh_SERVER_EVAL_x64FRE_en-us_1.iso'
Get-LabInternetFile -Uri $serverUri -Path $labsources\ISOs -FileName Server2019eval.iso
Get-ChildItem $labsources
#endregion

#region Lab 1
# That's it - a simple lab could look like this
New-LabDefinition -Name NIC2020Lab1 -DefaultVirtualizationEngine HyperV
Set-LabInstallationCredential -Username someUser -Password Somepass1
Add-LabMachineDefinition -Name NIC2020-H1
Install-Lab

# Interacting with lab machines (WinRM)
$session = New-LabPSSession -ComputerName NIC2020-H1
Enter-PSSession
Enter-LabPSSession -ComputerName NIC2020-H1
(Get-LabVm -ComputerName NIC2020-H1).GetCredential((Get-Lab)) # pscredential
(Get-LabVm -ComputerName NIC2020-H1).GetCredential((Get-Lab)).GetNetworkCredential().Password

# The same script can be used on Azure as well
New-LabDefinition -Name NIC2020Lab1 -DefaultVirtualizationEngine Azure -AzureSubscriptionName JHPaaS

# Every 7 days or on demand: Sync installation files so that they are uploaded only once
Sync-LabAzureLabSources -MaxFileSizeInMb 50 # Goes to Azure File Storage
Add-LabMachineDefinition -Name NIC2020-H1
Install-Lab

# By the way: The available operating systems are not only confined to Microsoft
# We currently support CentOS and openSUSE. We plan on adding Debian/Ubuntu when I have some spare time
Get-LabAvailableOperatingSystem | Where-Object OperatingSystemType -eq Linux

# So, now that we have a VM, how can you connect to it? We don't know any credentials :'(
$session = New-LabPSSession -ComputerName NIC2020-H1 # Create or reuse
$eventFilter = @{ID = 6005; LogName='System'}
Invoke-Command -Session $session -ScriptBlock {Get-WinEvent -FilterHashtable $using:eventFilter}

# Invoke-LabCommand can do a bit more...
Invoke-LabCommand -ComputerName NIC2020-H1 -Variable (Get-Variable eventFilter) -ScriptBlock {
    # No need to modify your scripts any longer
    Get-WinEvent -FilterHashtable $eventFilter
} -NoDisplay -PassThru

Get-Command -Module AutomatedLab.Common # Independent from AutomatedLab
Find-CertificateAuthority -DomainName contoso.com
Add-FunctionToPSSession -Session (Get-LabPSSession NIC2020-H1) -FunctionInfo (Get-COmmand Find-CertificateAuthority)

# The credential can of course be retrieved for other purposes
$machine = Get-LabVm NIC2020-H1
$machine.GetCredential((Get-Lab))
$machine.GetCredential((Get-Lab)).GetNetworkCredential().Password

# There are plenty of other helpful cmdlets
$rdpFile = Get-LabVMRdpFile -ComputerName NIC2020-H1 -Path D:\tmp
start $rdpFile.FullName
Get-HostEntry -Section NIC2020Lab1 -HostName NIC2020-H1

# We are done with this easy lab
Remove-Lab -Confirm:$false

Get-LabAvailableOperatingSystem
Clear-LabCache # At the moment: Registry
#endregion

#region Lab 2
# Now something a bit more interesting
New-LabDefinition -Name NIC2020Lab2 -DefaultVirtualizationEngine HyperV

# Auto-defined Root Domain Controller (and ADDS deployment)
# and a Root Certificate Authority to test web apps with SSL certificates
# Post Installations can be used to customize the environment even more
$postInst = @(
    Get-LabPostInstallationActivity -ScriptFileName 'New-ADLabAccounts 2.0.ps1' -DependencyFolder $labSources\PostInstallationActivities\PrepareFirstChildDomain
    Get-LabPostInstallationActivity -ScriptFileName PrepareRootDomain.ps1 -DependencyFolder $labSources\PostInstallationActivities\PrepareRootDomain
)

# Roles can be configured as well, usually with plenty of options
$dcRole = Get-LabMachineRoleDefinition -Role RootDC -Properties @{
    SiteName = 'Oslo'
    #IsReadOnly = 'true'
}
Add-LabMachineDefinition -Domain contoso.com -Role $dcRole,CARoot -Name NIC2020-DC1 -PostInstall $postInst -Memory 4GB

# How many roles do we support?
[enum]::GetValues([AutomatedLab.Roles]) -join ', '
Get-ChildItem $labsources\CustomROles

# A humble web server
Add-LabMachineDefinition -Domain contoso.com -Role WebServer -Name NIC2020-FS1 -Memory 4GB

Install-Lab # This entire deployment takes roughly 15 minutes

# Saving some time
Import-Lab -Name NIC2020Lab2 -NoValidation -NoDisplay
Start-LabVm -All -Wait

# Other things to do with your entire lab
Checkpoint-LabVM -All -SnapshotName BeforeDestroyingTheLab
Install-LabWindowsFeature -ComputerName NIC2020-FS1 -FeatureName RSAT-AD-Tools
$status = Install-LabSoftwarePackage -Path "$labSources\SoftwarePackages\Notepad++.exe" -CommandLine '/S' `
                        -ComputerName NIC2020-FS1 -PassThru
if ($status.ExitCode -notin 0,3010) {"oh oh"}
Enable-LabCertificateAutoenrollment -Computer # -User, -CodeSigning
$cert = Request-LabCertificate -ComputerName NIC2020-FS1 -Subject "CN=NIC2020-FS1" `
        -SAN (Get-LabVm -ComputerName NIC2020-FS1).FQDN -TemplateName WebServer -PassThru
Invoke-LabCommand -Computer NIC2020-FS1 -Variable (Get-Variable cert) -ScriptBlock {
    New-WebBinding -Name "Default Web Site" -IP "*" -Port 443 -Protocol Https
    $binding = Get-WebBinding -Protocol Https
    $binding.AddSslCertificate($cert.Thumbprint, 'My')
    Invoke-RestMethod https://NIC2020-FS1.contoso.com # Bingo
} -PassThru
Restore-LabVMSnapshot -SnapshotName BeforeDestroyingTheLab -All
Remove-LabVMSnapshot -SnapshotName BeforeDestroyingTheLab -AllMachines

# So what about adding things? Do you need to redeploy?
Add-LabMachineDefinition -Name NIC2020-FS2
Install-Lab # Install-Lab takes care of the redeployment if necessary

# Want to get rid of some machines without scrapping the lab? We got you.
Remove-LabVm -Name NIC2020-FS2
#endregion

#region Recipes
# All too complicated? Or not fancy enough?
# Do you want a more Infrastructure-as-code-y look? Try our DSL instead
LabRecipe NicRecipeLab {
    VmPrefix = 'AUTO'
    DeployRole = 'Domain', 'PKI'
    DefaultAddressSpace = '192.168.27/24'
} | Invoke-LabRecipe -NoDeploy -PassThru

# Recipes can be stored for reuse
LabRecipe NicRecipeLab {
    VmPrefix = 'AUTO'
    DeployRole = 'Domain', 'PKI', 'Exchange'
    DefaultAddressSpace = '192.168.27/24'
} | Save-LabRecipe

Get-LabRecipe -Name NicRecipeLab | Invoke-LabRecipe

# Install
LabRecipe NicRecipeLab {
    VmPrefix = 'AUTO'
    DeployRole = 'Domain', 'PKI'
    DefaultAddressSpace = '192.168.27/24'
} | Invoke-LabRecipe
#endregion

#region AutomatedLab.Common

# We distilled a lot of common functionality in a separate library
(Get-Command -Module AutomatedLab.Common).Count
Get-NetworkSummary -IPAddress 192.168.2.32 -SubnetMask 255.255.255.252
$session = New-LabPSSession -ComputerName NIC2020-FS1
$someVariable = 42
Add-VariableToPSSession -Session $session -PSVariable (Get-Variable someVariable)
Add-FunctionToPSSession -Session $session -FunctionInfo (Get-Command Get-StringSection)
Send-ModuleToPSSession -Session $session -Module (Get-Module -ListAvailable -Name Polaris) -IncludeDependencies
Invoke-Command -Session $session -ScriptBlock {
    Get-StringSection -String 'aabbccddeeff' -SectionSize 2
    Get-Module -ListAvailable Polaris
}

#endregion