﻿# Getting started is easy
Install-Module AutomatedLab -AllowClobber
Import-Module AutomatedLab

# First things first - only done once
New-LabSourcesFolder -Drive D
Enable-LabHostRemoting -Force
Enable-LabTelemetry # Or Disable-LabTelemetry, that's up to you! It is DISABLED by default.

# Provide the ISOs you want, whether it is an operating system or a product like SQL, Exchange, Azure DevOps Server, ...
$serverUri = 'https://software-download.microsoft.com/download/pr/17763.737.190906-2324.rs5_release_svc_refresh_SERVER_EVAL_x64FRE_en-us_1.iso'
Get-LabInternetFile -Uri $serverUri -Path $labsources\ISOs -FileName Server2019eval.iso

#region Lab 1
# That's it - a simple lab could look like this
New-LabDefinition -Name NIC2020Lab1 -DefaultVirtualizationEngine HyperV 
Add-LabMachineDefinition -Name NIC2020-H1
Install-Lab

# By the way: The available operating systems are not only confined to Microsoft
# We currently support CentOS and openSUSE. We plan on adding Debian/Ubuntu when I have some spare time
Get-LabAvailableOperatingSystem | Where-Object OperatingSystemType -eq Linux

# So, now that we have a VM, how can you connect to it? We don't know any credentials :'(
$session = New-LabPSSession -ComputerName NIC2020-H1 # Create or reuse
$eventFilter = @{ID = 6005; LogName='System'}
Invoke-Command -Session $session -ScriptBlock {Get-WinEvent -FilterHashtable $using:eventFilter}

# Invoke-LabCommand can do a bit more...
Invoke-LabCommand -ComputerName NIC2020-H1 -Variable (Get-Variable eventFilter) -ScriptBlock {
    # No need to modify your scripts any longer
    Get-WinEvent -FilterHashtable $eventFilter
} -NoDisplay -PassThru

# The credential can of course be retrieved for other purposes
$machine = Get-LabVm NIC2020-H1
$machine.GetCredential((Get-Lab))
$machine.GetCredential((Get-Lab)).GetNetworkCredential().Password

# There are plenty of other helpful cmdlets
$rdpFile = Get-LabVMRdpFile -ComputerName NIC2020-H1 -Path D:\tmp
start $rdpFile.FullName

# We are done with this easy lab
Remove-Lab -Confirm:$false
#endregion

#region Lab 2
# Now something a bit more interesting
New-LabDefinition -Name NIC2020Lab2 -DefaultVirtualizationEngine HyperV

# Auto-defined Root Domain Controller (and ADDS deployment)
# and a Root Certificate Authority to test web apps with SSL certificates
# Post Installations can be used to customize the environment even more
$postInst = @(
    Get-LabPostInstallationActivity -ScriptFileName 'New-ADLabAccounts 2.0.ps1' -DependencyFolder $labSources\PostInstallationActivities\PrepareFirstChildDomain
    Get-LabPostInstallationActivity -ScriptFileName PrepareRootDomain.ps1 -DependencyFolder $labSources\PostInstallationActivities\PrepareRootDomain
)

# Roles can be configured as well, usually with plenty of options
$dcRole = Get-LabMachineRoleDefinition -Role RootDC -Properties @{
    SiteName = 'Oslo'
}
Add-LabMachineDefinition -Domain contoso.com -Role $dcRole,CARoot -Name NIC2020-DC1 -PostInstall $postInst -Memory 4GB

# How many roles do we support?
[enum]::GetValues([AutomatedLab.Roles])

# A humble web server
Add-LabMachineDefinition -Domain contoso.com -Role WebServer -Name NIC2020-FS1 -Memory 4GB

Install-Lab # This entire deployment takes roughly 15 minutes

# Saving some time
Import-Lab -Name NIC2020Lab2 -NoValidation -NoDisplay
Start-LabVm -All -Wait

# Other things to do with your entire lab
Checkpoint-LabVM -All -SnapshotName BeforeDestroyingTheLab
Install-LabWindowsFeature -ComputerName NIC2020-FS1 -FeatureName RSAT-AD-Tools
Install-LabSoftwarePackage -Path "$labSources\SoftwarePackages\Notepad++.exe" -Argument '/S'
Enable-LabCertificateAutoenrollment -Computer
$cert = Request-LabCertificate -ComputerName NIC2020-FS1 -Subject "CN=NIC2020-FS1" -SAN (Get-LabVm -ComputerName NIC2020-FS1).FQDN -TemplateName WebServer -PassThru
Invoke-LabCommand -Computer NIC2020-FS1 -Variable (Get-Variable cert) -ScriptBlock {
    New-WebBinding -Name "Default Web Site" -IP "*" -Port 443 -Protocol Https
    $binding = Get-WebBinding -Protocol Https
    $binding.AddSslCertificate($cert.Thumbprint, 'My')
    Invoke-RestMethod https://NIC2020-FS1.contoso.com # Bingo
}
Restore-LabVMSnapshot -SnapshotName BeforeDestroyingTheLab -All
Remove-LabVMSnapshot -SnapshotName BeforeDestroyingTheLab -All
Remove-Lab
#endregion

#region Recipes
# All too complicated? Or not fancy enough? Try our DSL instead
LabRecipe NicRecipeLab {
    VmPrefix = 'AUTO'
    DeployRole = 'Domain', 'PKI'
    DefaultAddressSpace = '192.168.27/24'
} | Invoke-LabRecipe -NoDeploy -PassThru

# Recipes can be stored for reuse
LabRecipe NicRecipeLab {
    VmPrefix = 'AUTO'
    DeployRole = 'Domain', 'PKI'
    DefaultAddressSpace = '192.168.27/24'
} | Save-LabRecipe

Get-LabRecipe -Name NicRecipeLab

# Install
LabRecipe NicRecipeLab {
    VmPrefix = 'AUTO'
    DeployRole = 'Domain', 'PKI'
    DefaultAddressSpace = '192.168.27/24'
} | Invoke-LabRecipe
#endregion

#region AutomatedLab.Common

# We distilled a lot of common functionality in a separate library
Get-Command -Module AutomatedLab.Common
Get-NetworkSummary -IPAddress 192.168.2.32 -SubnetMask 255.255.255.252
$session = New-LabPSSession -ComputerName NIC2020-FS1
$someVariable = 42
Add-VariableToPSSession -Session $session -PSVariable (Get-Variable someVariable)
Add-FunctionToPSSession -Session $session -FunctionInfo (Get-Command Get-StringSection)
Send-ModuleToPSSession -Session $session -Module (Get-Module -ListAvailable -Name Polaris) -verbose -IncludeDependencies
Invoke-Command -Session $session -ScriptBlock {
    Get-StringSection -String 'aabbccddeeff' -SectionSize 2
    Get-Module -ListAvailable Polaris
}

#endregion