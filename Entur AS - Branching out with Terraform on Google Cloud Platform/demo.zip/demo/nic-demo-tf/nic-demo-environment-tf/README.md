# Terraform for NIC demo

Set up in Harness. Take `kubernetes_namespace` as a parameter.