#
# Harness Delegate 
# base-profile
#
echo "apt-get update"
yes | apt-get update

echo "Install gcloud"
echo "deb [signed-by=/usr/share/keyrings/cloud.google.gpg] http://packages.cloud.google.com/apt cloud-sdk main" | tee -a /etc/apt/sources.list.d/google-cloud-sdk.list && curl https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key --keyring /usr/share/keyrings/cloud.google.gpg  add - && apt-get update -y && apt-get install google-cloud-sdk -y

echo "Install terraform"
curl -O -L  https://releases.hashicorp.com/terraform/0.12.19/terraform_0.12.19_linux_amd64.zip
unzip terraform_0.12.19_linux_amd64.zip
mv ./terraform /usr/bin/
# Check TF install
terraform --version

echo "Install jq"
dpkg -l | grep -qw jq || apt-get install jq -y

echo "Install git"
apt-get -y install git

# overcome the fact Bitbucket SSH does not multiplex
export GIT_SSH_COMMAND="ssh -o ControlPath=none"