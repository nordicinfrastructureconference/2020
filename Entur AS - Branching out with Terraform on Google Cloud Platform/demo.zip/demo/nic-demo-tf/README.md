# Terraform for NIC demo

## Create a project in Goocle Cloud

You know how to do this.

## Create a bucket in GCS

You know how to do this.

Then update `backend.tf` in each repository to point to your bucket by name.

## Configure Harness with Delegate

* Visit https://app.harness.io/
* Click Setup (top right corner)
* Click Harness Delegates (right Account pane)
* Click Manage Delegate Profiles
* Click base-profile (or create a new profile named base-profile if none exists)
* Paste the contents from ./harness-base-profile.sh into the modal text field.
* Save and close

## Find your Harness secrets

* Visit https://app.harness.io/
* Click Setup (top right corner)
* Click Harness Delegates (right Account pane)
* Click Download Delegate (top right below application bar)
* Select Kubernetes Yaml
* Name the delegate something (f.ex demo - does not matter)
* Select `base-profile` from the Profile dropdown.
* Unzip the tar.gz, open harness-delegate.yamls
* search for `ACCOUNT_ID`, and you will find the following nearby

    export TF_VAR_harness_secret=ACCOUNT_SECRET_value
    export TF_VAR_harness_account_id=ACCOUNT_ID_value
    export TF_VAR_harness_delegate_profile=DELEGATE_PROFILE_value

* Search for `harness.io/account` and set the value to

    export TF_VAR_harness_account_id_short=ACCOUNT_VALUE

## Congratulations! You are ready to spin up a cluster!

    export TF_VAR_bucket=YOUR_BUCKET_NAME_FOR_TF_BACKEND
    export TF_VAR_gcp_project=YOUR_PROJECT_NAME
    export TF_VAR_region=YOUR_REGION
    export TF_VAR_zone=YOUR_ZONE
    export TF_VAR_cluster_name=YOUR_CLUSTER_NAME
    cd nic-demo-cluster-tf && terraform apply
    cd nic-demo-cluster-init-tf && terraform apply
