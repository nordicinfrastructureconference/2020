'use strict';

const express = require('express');
const path = require('path');
const { Pool, Client } = require('pg')
const Quote = require('inspirational-quotes');

// Constants
const HOST = '0.0.0.0';
const PORT = process.env.PORT || 8080;
const PGUSER = process.env.PGUSER || "postgres";
const PGHOST = process.env.PGHOST || "localhost";
const PGPASSWORD = process.env.PGPASSWORD || "postgres";
const PGDATABASE = process.env.PGDATABASE || "nicdemo";
const PGPORT = process.env.PGPORT || 5432;
const config = {
  host: PGHOST,
  user: PGUSER,
  password: PGPASSWORD,
  database: PGDATABASE,
};
const init = new Pool(config)
const create = 'CREATE TABLE IF NOT EXISTS quotes (id bigserial primary key, message text, author varchar(128));'
init.query(create)
  .catch(e => console.error(e.stack));
init.end()

// App
const app = express();

app.set('view engine', 'pug')
app.use('/public', express.static(path.join(__dirname, 'public')))
app.use('/health', function (req, res) {
  res.send(200)
})
app.get('/', async function (req, res) {
  const quote = Quote.getQuote()
  const text = 'INSERT INTO quotes(author, message) VALUES($1, $2);'
  const values = [quote.author, quote.text]
  const pool = new Pool(config)
  pool.query(text, values)
    .catch(e => console.error(e.stack));
  pool.query('SELECT * from quotes;', (err, dat) => {
    res.render('index', {
      title: 'Quotes', header: 'Entur <3 NIC', rows: dat.rows
    })
    pool.end()
  })
})

app.listen(PORT, HOST);
console.log(`Running on http://${HOST}:${PORT}`);