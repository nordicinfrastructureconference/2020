#!/bin/bash
git checkout master && git checkout -b $1 && git commit --allow-empty -m "make PR [skip ci]" && git push -u origin $1  