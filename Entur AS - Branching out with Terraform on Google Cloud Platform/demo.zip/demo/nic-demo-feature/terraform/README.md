# Terraform configuration Template

## Structure
This repo contains a `./terraform` folder (your current folder) which is built up of:

 *  `backend.tf`: Connects to the GCS backend in entur-system-1287
 *  `main.tf`: Terraform configuration
 *  `variables.tf`: All variables used in the configuration, including default values where applicable
 *  `environment folders`: contains .tfvars files corresponting to a terraform workspace overwrites default values in variables file.
 *  `.tfswitchrc`: Contains the terraform version used to run the configuration. Used with the tfswitch tool

## Required modifications before usage
* `backend.tf`: change `TEAMNAME` and `REPONAME`. Contact Team Plattform for bucket setup if this is your teams first terraform project
* `variables.tf`: Modify the labels used by your team.

## Describe your infrastructure
Please refer to our [Terraform Modules](https://github.com/entur/terraform) before gooling and using lower level Terraform primitives. 
If you find yourself needing the same thing over and over - concider making it a module and do a PR against repository above.

## Running terraform configuration
All commands are run from the root of the repository. 

Example using the dev environment:

 1.  Change to the dev terraform workspace `terraform workspace select rtd-<configuration-name>`
 2.  Run a terraform plan to verify what changes will be done to the environment `terraform plan -var-file="dev/dev.tfvars"`
 3.  Run a terraform apply to apply the changes to the environment `terraform apply -var-file="dev/dev.tfvars"`
 4.  Push the local changes to this repository

## Adding a new environment
All terraform commands are run from the root of the repository.

 1.  Create a new environment folder
 2.  Create a .tfvar file following the structure of one of the existing .tfvar files
 3.  Create a new terraform workspace `terraform workspace new <env>-gke`
 4.  Import all previously existing reseources by running the terrafrom import command described in each dokumentation page. Example:  https://www.terraform.io/docs/providers/google/r/container_cluster.html
 5.  Run a terraform plan to verify what changes will be done to the environment `terraform plan -var-file="<env>/<env>.tfvars"`
 6.  Run a terraform apply to apply the changes to the environment `terraform apply -var-file="<env>/<env>.tfvars"`
 7.  Push the local changes to this repository
