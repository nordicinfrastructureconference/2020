# Entur <3 NIC

This is a demonstration project for a presentation at NIC 2020