'use strict';

const express = require('express');
const path = require('path');
const { Pool, Client } = require('pg')
const Quote = require('inspirational-quotes');

// Constants
const HOST = '0.0.0.0';
const PORT = process.env.PORT || 8080;
const PGUSER = process.env.PGUSER || "postgres";
const PGHOST = process.env.PGHOST || "localhost";
const PGPASSWORD = process.env.PGPASSWORD || "postgres";
const PGDATABASE = process.env.PGDATABASE || "nicdemo";
const PGPORT = process.env.PGPORT || 5432;
const config = {
  host: PGHOST,
  user: PGUSER,
  password: PGPASSWORD,
  database: PGDATABASE,
};

// App
const app = express();

app.set('view engine', 'pug')
app.use('/public', express.static(path.join(__dirname, 'public')))
app.use('/health', function (req, res) {
  res.send(200)
})
app.get('/', async function (req, res) {
  res.render('index', {
    title: 'Hey', header: 'Entur <3 NIC'
  })
})

app.listen(PORT, HOST);
console.log(`Running on http://${HOST}:${PORT}`);

